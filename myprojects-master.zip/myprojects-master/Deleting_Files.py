import os

dir = str(input('Enter your path: '))

for folders, subfolders, files in os.walk(dir):
    for file in files:
        if os.path.getsize(os.path.join(folders, file)) > 10000000:
            print(os.path.join(folders, file))
