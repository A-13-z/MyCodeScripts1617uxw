def sum_numbers(num):
    n = (0.5 * num) + 0.5

    sum = num * n

    print(int(sum))


#sum_numbers(45) to call the function ; outputs 1035
