from django.db import models

# Create your models here.

class score(models.IntegerChoices):
    abhorrent = 0
    yuck = 1
    bad = 2
    fine = 3
    good = 4
    awesome = 5

class Favorite_Movie(models.Model):
    movie = models.CharField(max_length=250)
    userID = models.IntegerField()
    rating = models.IntegerField(choices=score.choices)


