import random
num = random.randint(0, 20)
inp = input('Guess a number between 0 and 20: ')
x = True
while x:
    try:
        if int(inp) not in range(0, 21):
            inp = input('Guess a number between 0 and 20: ')
        elif num < int(inp):
            inp = input('You guess is too high! Guess a number: ')
        elif num > int(inp):
            inp = input('You guess is low! Guess a number: ')
        elif num == int(inp):
            print('You have guessed the number. It is ' + str(num))
            x = False
    except ValueError:
        inp = input('ENTER A INTEGER NOT A WORD: ')
