class Stack:
    def __init__(self):
        self.stack = list()

    def isEmpty(self):
        if len(self.stack) == 0:
            return "Empty!"
        
        else: 
            return "Something is there"                     #add isEmpty() to validate the list to lifo() and peek()

    def add(self, value):                          
        self.stack.append(value)

    def lifo(self):
        self.stack.pop()

    def iterate(self):
        for i in self.stack:
            print(i + "\n")
    
    def peek(self):
        print(self.stack[-1])

    def size(self):
        print(len(self.stack))
