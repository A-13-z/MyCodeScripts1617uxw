def Result(List):
    i = 0
    j = 0
    k = 0
    l = 0
    m = 0
    ans = ""
        
    while m != 1:
        if List[i][k] == List[j][k]:
            l += 1
            if j < len(List) - 1:
                j += 1
            elif j == len(List) - 2:
                k += 1
                j = 0
            elif l == len(List):
                ans += List[i][k]
                l = 0
                k += 1
        else:
            m += 1
                
    return ans

#List = ["flower","flow","flight"]
#List = ["dog","racecar","car"]
#List = ['Dora', 'Doremon', 'Ninja']    #testcode
#List = ['apple', 'ape', 'april']
print(Result(List))
