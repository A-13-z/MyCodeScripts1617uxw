import re

file = open('mdlib.txt')

pattern = re.compile(r'(ADJECTIVE)|(NOUN)|(VERB)|(ADVERB)')

content  = file.read()

key = pattern.findall(content)

for i  in key:
  for j in i:
      if j != '':
        pattern2 = re.compile(r'{}'.format(j)
        inp = str(input('Enter any %s' % j ))
        content = re.sub(pattern2, inp, 1)

print(content)

file = open('mdlib2.txt', 'w')
file.write(content)
file.close()
