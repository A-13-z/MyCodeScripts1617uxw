from selenium import webdriver
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome(executable_path='C:/path/to/chromedriver.exe')

browser.get('https://play2048.co')

html = browser.find_element_by_tag_name('html')

while True:
    html.send_keys(Keys.ARROW_UP)
    html.send_keys(Keys.ARROW_RIGHT)
    html.send_keys(Keys.ARROW_DOWN)
    html.send_keys(Keys.ARROW_LEFT)

browser.quit()
