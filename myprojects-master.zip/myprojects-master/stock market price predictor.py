import pandas
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split

stock = pandas.read_csv('C:/Users/pc/Downloads/portfolio_data.csv')   #location of your dataset

stock_rev = stock[['AMZN', 'DPZ', 'BTC', 'NFLX']]           #column headers

stock_ind = [i for i in range(0, 1520)]         #length

df = pandas.DataFrame(stock_rev, index = stock_ind)

df1 = df.drop(df.index[1519])

df2 = df.drop(df.index[0])

# print(df1) #used for testing purposes

# print(df2)

x_train, x_test, y_train, y_test = train_test_split(df1, df2, test_size = 0.50, random_state = 1)

reg = Lasso(alpha=0.1).fit(x_train, y_train)

print(reg.score(x_test, y_test) * 100)  #output = 0.9974599921283979

