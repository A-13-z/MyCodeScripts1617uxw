def arrayMaxConsecSum2(arr):
    max_ = arr.index(max(arr))
    p1 = [sum(arr[:max_ + 1][:i + 1]) for i in range(len(arr[:max_ + 1])) if max_ + 1 != 0]
    p2 = [sum(arr[max_:][:i + 1]) for i in range(len(arr[max_:]))  if max_ != len(arr)]
    return max(sum(arr), max(p1), max(p2))

#print(arrayMaxConsecSum2([1, 2, 3, 4]))
