# learning_ml_ai
Contains code pertaining to various AI/ML concepts. This will document my learning journey.

## Corrections
### In Learning Phase Representations there seems to be an issue with the Multi30k dataset of torchtext. Github issue is:- https://github.com/pytorch/text/issues/2221
