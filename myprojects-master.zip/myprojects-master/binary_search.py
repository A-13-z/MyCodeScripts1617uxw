nl = []
for i in range(1, 201):
    nl.append(i)

num = int(input('Enter the number you want to search: '))

l = 0
r = len(nl) - 1 

found = False
while (l <= r and not found):
    mid = (l + r)//2
    if nl[mid] == num:
        found = True
    else:
        if num < nl[mid]:
            r = mid - 1
        else:
            l = mid + 1
print(found)
