from django import forms

class MovieForm(forms.Form):
    similar_movie = forms.CharField(max_length = 250)
    how_many = forms.IntegerField(max_value=100)