from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
import numpy as np
import pandas as pd
from .forms import MovieForm
import re
from dal import autocomplete
# Create your views here.
def index(request):
    form = MovieForm(request.POST)
    return render(request, 'recommendation_maker/index.html', {'form': form})

def recommendations(request):
    form = MovieForm(request.POST)
    if form.is_valid():
        final_movies = pd.read_csv('D:/documents/coding projects/ML/final_movies.csv')

        mov = form.cleaned_data.get("similar_movie").lower().replace(" ", "").replace(':', '')
        how_much = form.cleaned_data.get("how_many")
        des_rating = 4
        lst = set([b for a, b in zip(final_movies['title'], final_movies['genres']) if a.lower() == mov])
        gen = list(lst)
        genr = gen[0].split('|')
        print(genr)
        de = set([a for a, b, c in zip(final_movies['title'], final_movies['genres'], final_movies['rating']) for i in genr if i in str(b).split('|') if a.lower() != mov if c >= des_rating])
        
        def organise(lt):
            common = 0
            for i in final_movies['genres']:
                y = str(i).split('|')
                for j in y:
                    if j in genr:
                        common += 1
            return common

        fina = list(de)
        fina.sort(key=organise)

        final = {'final':fina[:how_much]}
        
        return render(request, 'recommendation_maker/results.html', final)