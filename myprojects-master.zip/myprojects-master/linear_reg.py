import tensorflow as tf
from sklearn.preprocessing import scale
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split

features, prices = load_boston(True)
x_train, x_test, y_train, y_test = train_test_split(features, prices, test_size = 0.33, random_state = 25)

train_features = tf.cast(scale(x_train), dtype = tf.float32)
train_prices = y_train

test_features = tf.cast(scale(x_test), dtype = tf.float32)
test_prices = y_test

def build_model():
    model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu'), 
    tf.keras.layers.Dense(64, activation= 'relu'),
    tf.keras.layers.Dense(1)])

    optimiser = tf.keras.optimizers.RMSprop(0.001)

    model.compile(optimizer=optimiser, loss = 'mse', metrics=['mae', 'mse'])

    return model

model = build_model()

early_stop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience = 10)

history = model.fit(train_features, train_prices, epochs = 10000, validation_split= 0.2, verbose = 0, callbacks = [early_stop])

loss, mae, mse = model.evaluate(test_features, test_prices, verbose = 2)

test_predictions = model.predict(test_features).flatten()
train_predictions = model.predict(train_features).flatten()

error = test_predictions - test_prices
print(error)

print("Actual:")
print(test_prices[19])
print("Prediction:")
print(test_predictions[19])

print(sum(error)/len(error)) #mean error
