import os
import requests
import bs4


search = str(input('Enter your query: '))

url = 'http://imgur.com/search?q=' + search 

os.makedirs('/images', exist_ok=True)

res = requests.get(url)

soup = bs4.BeautifulSoup(res.text, 'html.parser')
image_elem = soup.select('.post > .image-list-link img')

for i, image in enumerate(image_elem):
    img_url = 'https:' + image_elem[i].get('src')

    print('Downloading ' + str(img_url))
    result = requests.get(img_url)

    image_file = open(os.path.join('/images', os.path.basename(img_url)), 'wb')

    for chunk in result.iter_content(1000000):
            image_file.write(chunk)
    image_file.close()

print('\nDownload over')
