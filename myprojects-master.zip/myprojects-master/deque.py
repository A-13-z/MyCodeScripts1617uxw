class Deque:
    def __init__(self):
        self.deque = list()
    
    def isEmpty(self):
        if len(self.deque) == 0:
            return True
        else:
            return False

    def insertFront(self, value):
        self.deque.insert(0, value)

    def insertLast(self, value):
        self.deque.append(value)

    def removeFirst(self):
        if not (self.isEmpty()):
            self.deque.pop(0)
        else:
            print("Empty!")
    
    def removeLast(self):
        if not (self.isEmpty()):
            self.deque.pop()
        else:
            print("Empty!")

    def peekFirst(self):
        if not (self.isEmpty()):
            print(self.deque[0])
        else:
            print("Empty!")

    def peekLast(self):
        if not (self.isEmpty()):
            print(self.deque[-1])
        else:
            print("Empty!")

    def iterator(self):
        for i in self.deque:
            print(i)
