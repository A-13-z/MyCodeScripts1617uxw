from django.contrib import admin
from .models import Favorite_Movie
# Register your models here.

admin.site.register(Favorite_Movie)