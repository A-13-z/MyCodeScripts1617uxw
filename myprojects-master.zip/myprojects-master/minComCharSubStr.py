def minCommonCharSubStr(s, t):
    l1 = 0
    l2 = len(t)
    d1 = {i:t.count(i) for i in t}
    d2 = {i:t.count(i) for i in s[l1:l2] if i in t}
    if l1 == l2:
        return l1
    elif s == '':
        return None
    elif t == '':
        return s
    elif {i: t.count(i) for i in s if i in t}.keys() != d1.keys():
        return None
    while d2 != d1:
        l1 += 1
        l2 += 1
        d2 = {i:t.count(i) for i in s[l1:l2] if i in t}
        if l2 == len(s) + 1:
            l2 = l2 - l1 + 1
            l1 = 0
            d2 = {i:t.count(i) for i in s[l1:l2] if i in t}
    return s[l1:l2]
