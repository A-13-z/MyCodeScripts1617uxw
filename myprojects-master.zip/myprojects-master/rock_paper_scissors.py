import random

chances = 0
us = 0
cs = 0
options = ['rock', 'paper', 'scissors']
comp = random.choice(options)
user = str(input('Rock or Paper or Scissors: ')).lower()
while chances < 3:
    if user == 'rock':
        if comp == 'paper':
            cs += 1
            print('Computer gets 1 point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        elif comp == 'scissors':
            us += 1
            print('You get a point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        else:
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Try Again: ')).lower()
    if user == 'paper':
        if comp == 'scissors':
            cs += 1
            print('Computer gets 1 point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        elif comp == 'rock':
            us += 1
            print('You get a point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        else:
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Try Again: ')).lower()
    if user == 'scissors':
        if comp == 'rock':
            cs += 1
            print('Computer gets 1 point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        elif comp == 'paper':
            us += 1
            print('You get a point')
            chances += 1
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Rock or Paper or Scissors: ')).lower()
        else:
            if chances != 3:
                comp = random.choice(['rock', 'paper', 'scissors'])
                user = str(input('Try Again: ')).lower()

    if user not in options:
        user = str(input('Enter a valid input: ')).lower()
        
else:
    if cs > us:
        print('Computer wins')
        print('Your score: ' + str(us))
        print("Computer's score: " + str(cs))
    else:
        print('You win')
        print('Your score: ' + str(us))
        print("Computer's score: " + str(cs))
