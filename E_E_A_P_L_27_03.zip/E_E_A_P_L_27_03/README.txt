This folder contains the code and relevant files for the course EE2703

Assignment 1:- Matrix Multiplication
Assignment 2:- SPICE simulator
Assignment 3:- Curve Fitting
Assignment 4:- Keyboard Layout Analysis
Assignment 5:- Keyboard Layout Optimization
Assignment 6:- Cython:- Optimizing Python Code
Assignment 7:- Sound wave localization - finding the location of obstacles