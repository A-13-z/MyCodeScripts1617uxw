def LIS(lis):
    if len(lis) <= 2:
        return [max(lis)]
    if len(lis) == 0:
        return []
    l1 = 0
    c = []
    l2 = c[:]
    d = []
    while l1 < len(lis) - 1:
        c = []
        c.append(lis[l1])
        for i in range(l1, len(lis)):
            if c[-1] < lis[i]:
                c.append(lis[i])
                d.append(l2)
                l1 += 1
                l2 = c
    return max(d, key=len)
