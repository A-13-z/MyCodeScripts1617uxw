def count_vowels(string):
    string = string.lower()

    A = string.count('a')
    E = string.count('e')
    I = string.count('i')
    O = string.count('o')
    U = string.count('u')

    print(A + E + I + O + U)

count_vowels('Featuring')
