class Queue:
    def __init__(self):
        self.queue = list()

    def isEmpty(self):
        if len(self.queue) == 0:
            print("The Queue is empty you nitwit!")
            return True
        
        else: 
            #print("There is something in the queue, you single brain-celled homo sapien")
            return False

    def add(self, value):
        self.queue.append(value)

    def fifo(self):
        if not (self.isEmpty()):
            self.queue.pop(0)

    def iterate(self):
        for i in self.queue:
            print(i + "\n")

    def peek(self):
        print(self.queue[0])

    def size(self):
        print(len(self.queue))
