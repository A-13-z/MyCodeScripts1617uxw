def filter_list(lst):
    result = filter(lambda x: isinstance(x, int) == True, lst) 
    print(list(result)) 

filter_list([1, 'a', 'b', 2])
