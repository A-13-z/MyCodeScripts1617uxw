import os, re

inp = str(input())

pattern  = re.compile(inp, re.I)

cont = pattern.findall(query)

dir = os.getcwd()

files = os.listdir(dir)

for file in files:
  if file.endswith('.txt'):
      file_path = os.path.join(dir, file)   #the absolute path of the file
      print(file_path)
      file_open = open(file, 'r+')
      query = file_open.read()
      print(cont)
      
