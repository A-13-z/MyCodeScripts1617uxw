import os, shutil

dir = str(input('Enter the path you want to copy : '))

ext = str(input('Enter the extension you want to copy: '))

ml = str(input('Enter the path you want to move it to : '))

for folder, subfolder, files in os.walk(dir):
    for subfiles in subfolder:
        if subfiles.endswith(ext):
            shutil.copy(os.path.join(subfolder, subfiles), ml)

    for file in files:
        if file.endswith(ext):
            shutil.copy(os.path.join(folder, file), ml)

print('Copied')
