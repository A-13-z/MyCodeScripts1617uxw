def longestPalindromicSubString(string):
    if string == '' or len(string) == 1:
        return string
    x = []
    n = len(string)
    d = {x:string[x] for x in range(len(string)) if string.count(string[x]) > 1} 
    for i in d.keys():
        l = i
        h = n
        while string[l:h] != string[l:h][::-1] and h != l:
            h -= 1
        else:
            x.append(string[l:h])
    return max(x, key = len) if len(x) != 0 else None

print(longestPalindromicSubString(string))
