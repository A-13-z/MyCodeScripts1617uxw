import numpy as np
import pandas as pd

final_movies = pd.read_csv('Path to your dataset')          
fav_movie = 'Your favorite movie'           #can also store watched movies as a list and based on it you can modify the code using a for-loop
des_rating = 4            #the ratings of your recommended movies
lst = set([b for a, b in zip(final_movies['title'], final_movies['genres']) if a[:len(fav_movie)] == fav_movie])
gen = list(lst)
de = set([a for a, b, c in zip(final_movies['title'], final_movies['genres'], final_movies['rating']) for i in gen if b == i if a != fav_movie if c >= des_rating])
print('Similar to ' + fav_movie + '\n')
for j in range(1, len(sorted(list(de))) + 1):
    print(str(j) + ') ' + list(de)[j - 1], end='\n')
