def firstNonRepeatingChar(string):
    if len(set(list(string))) == len(string):
        return ''

    for i in string:
        if string.count(i) == 1:
            return i
