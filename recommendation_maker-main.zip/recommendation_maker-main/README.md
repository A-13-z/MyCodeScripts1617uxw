# recommendation_maker
This is my first try at Django and machine learning - together - as a whole.
