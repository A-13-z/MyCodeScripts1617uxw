import random
guess = str(input('Guess the coin toss (heads or tails) : ')) #I have added this as an extra
if guess not in ('heads', 'tails'):
    print('Guess the coin toss! Enter heads or tails:')
    guess = input()
    
norms = {0 : 'tails', 1 : 'heads'}
toss = norms[random.randint(0, 1)]  # 0 is tails, 1 is heads
if toss == guess:
    print('You got it!')
else:
    print('Nope! Guess again!')
    guess = input()
    if toss == guess:
        print('You got it!')
    else:
        print('Nope. You are really bad at this game.')

#All I did 👇🏼

#removed  the else
#reduced the indent
#removed the 's'
#created a dictionary called 'norms'
#changed the value of toss
#modified line 2
